/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package fractioncalc;

/**
 *
 * @author Siddiq Shah
 */
public class FractionCalc {

    public static void main(String[] args) {
        
        // for same value
        
        Fraction f1 = new Fraction(4, 12);
        Fraction f2 = new Fraction(3, 18);
        
        Fraction sum = f1.add(f2);
        sum.display();
        
//        Fraction subt = f1.subt(f2);
//        subt.display();
//        
//        Fraction mult = f1.mult(f2);
//        mult.display();
//        
//        Fraction divi = f1.divi(f2);
//        divi.display();
//        
//       Fraction findGCD = new Fraction(36,0);
//       findGCD.display();
        
        // for different value
//        Fraction f3 = new Fraction(6, 9);
//        Fraction f4 = new Fraction(3, 6);
//        
//        Fraction sum = f3.add(f4);
//        sum.display();
//        
//        Fraction subt = f3.subt(f2);
//        subt.display();
//        
//        Fraction mult = f1.mult(f2);
//        mult.display();
//        
//        Fraction divi = f1.divi(f2);
//        divi.display();
//        
//        divi.simplify();
//        divi.display();
    }
}
