package fractioncalc;


public class Fraction
{
    private int numerator;
    private int denomerator;
    
    
    public Fraction(int numerator, int denominator)
    {
        this.numerator = numerator;
        this.denomerator = denominator;
        
        simplify();
        if (denominator == 0)
        {
            System.out.println("You entered 0 less than zero.");
        }
    }
    
    public Fraction add(Fraction F) {
        int num, den;
        if (this.denomerator == F.denomerator) {
            den = this.denomerator;
            num = this.numerator + F.numerator;
        } else {
            den = this.denomerator * F.denomerator;
            num = (this.numerator * F.denomerator) + (this.denomerator * F.numerator);
        }

        Fraction sum = new Fraction(num, den);
        return sum;
        }
    
    
    public Fraction subt(Fraction F)
    {
        int num, den;
        if (this.denomerator == F.denomerator) {
            den = this.denomerator;
            num = this.numerator - F.numerator;
        } else {
            den = this.denomerator * F.denomerator;
            num = (this.numerator * F.denomerator) - (this.denomerator * F.numerator);
        }

        Fraction diff = new Fraction(num, den);
        return diff;
    }
    
    public Fraction mult(Fraction F)
    {
        int den = this.denomerator * F.denomerator;
        int num = (this.numerator * F.numerator);
        
        Fraction subt = new Fraction(num, den);
        return subt;
    }
    
    public Fraction divi(Fraction F)
    {
        int den = this.denomerator * F.numerator;
        int num = (this.numerator * F.denomerator);
        
        Fraction subt = new Fraction(num, den);
        return subt;
    }
    
//    public static int findGCD(int num1, int num2) {
//        while (num2 != 0) {
//            int temp = num2;
//            num2 = num1 % num2;
//            num1 = temp;
//        }
//        return num1;
//    }
//    public void simplify()
//    {
//        int gcd = findGCD(numerator,denomerator);
//        numerator = numerator / gcd;
//        denomerator = denomerator/ gcd;
//    }
    
    public void simplify()
    {
        int i = 0;
        for (i = 2; i <= numerator && i <= denomerator; i++) {
            if (numerator % i == 0 && denomerator % i == 0) {
                numerator = numerator / i;
                denomerator = denomerator / i;
            }
        }
    }
    
      public void display()
    {
        System.out.println(numerator + "/" + denomerator);
    }
}