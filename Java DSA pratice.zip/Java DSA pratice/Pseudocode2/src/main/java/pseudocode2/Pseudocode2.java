package pseudocode2;

import java.util.Scanner;

public class Pseudocode2 
{
    public static void main(String[] args) 
    {
        Scanner input = new Scanner(System.in);
        
        float unitsUsed, totalCost;
        float first200Rate, next800Rate, additionalRates;
        float first200Units, next800Units, additionalUnits;
        
        // Assign rates 
        first200Rate = 21.8f;
        next800Rate  = 25.8f;
        additionalRates = 27.8f;
        
        // Assign units limit
        first200Units = 200.0f;
        next800Units  = 800.0f;
        
        System.out.println("Enter the amount of units used:");
        unitsUsed = input.nextFloat();
        
        // Calculate the total cost
        if (unitsUsed <= 200)
        {
            totalCost = unitsUsed*first200Rate;
        }
        else if (unitsUsed <= first200Units+next800Units)
        {
            totalCost = ((first200Units*first200Rate)+
                    (unitsUsed-first200Units)*next800Rate);
        }
        else
        {
            totalCost = (first200Units*first200Rate)+
                    (next800Units*next800Rate)+((unitsUsed-first200Units-next800Units
                            )*additionalRates);
        }
                                
        System.out.println("Units used: "+unitsUsed);       
        System.out.println("Total cost: "+totalCost); 
   }
}
