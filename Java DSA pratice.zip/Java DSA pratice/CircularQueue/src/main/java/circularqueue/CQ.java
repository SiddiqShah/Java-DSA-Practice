package circularqueue;

public class CQ 
{
    private int[] queue;
    private int size, front, rear, FreeSlots;

    public CQ(int capacity) 
    {
        queue = new int[capacity];
        front = 0;
        rear = 0;
        size = 0;
        FreeSlots = capacity;
    }

    // EnQ and DeQ through Stack
    CQ pop(CQ queue)
    {
        CQ temp = new CQ(10);
        
        for(int i=0; i<size; i++)
        {
            temp.EnQ(queue.DeQ());
        }
        temp.DeQ();
        for(int i=0; i<size; i++)
        {
            temp.EnQ(queue.DeQ());
        }

        return queue;
    }
    
    // Check if the queue is full
    public boolean isFull() 
    {
        return size == queue.length;
    }

    // Check if the queue is empty
    public boolean isEmpty() 
    {
        return size == 0;
    }

    
    // Enqueue method (insert)
    public void EnQ(int Data) 
    {
        if (!isFull())  // Check if the queue is not full
        {
            queue[rear] = Data;
            rear = (rear + 1) % queue.length;  // Circular increment
            size++;
            FreeSlots--;
        } 
        else 
        {
            System.out.println("Queue is full. Cannot insert.");
        }
    }

    // Dequeue method (remove)
    public int DeQ() 
    {
        if (!isEmpty())  // Check if the queue is not empty
        {
            int value = queue[front];
            front = (front + 1) % queue.length;  // Circular increment
            size--;
            FreeSlots++;
            return value;
        } 
        else 
        {
            return -9999;  // Return sentinel value when the queue is empty
        }
}

    // Show method to display the current elements
    public void Show() 
{
    if (isEmpty()) {
        System.out.println("Queue is empty.");
    }

    System.out.println("Elements of the queue: ");
    for (int i = 0; i < size; i++) 
    {
        System.out.print(queue[(front + i) % queue.length] + " "); // Circular access
    }
    System.out.println();
}
    
//    public void newEle()
//    {
//        System.out.println("the newest value is: "+queue[front]);
//    }
//    
//    public void oldEle()
//    {
//        System.out.println("the oldest value is: "+queue[rear]);
//    }

}
