package circularqueue;

import java.util.Scanner;

public class CircularQueue {
    public static void main(String[] args) 
    {
        Scanner in = new Scanner(System.in);
        System.out.print("Circular queue size: ");
        int size = Integer.parseInt(in.nextLine());
        CQ obj = new CQ(size);
        
        while(true)
        {
            System.out.println("========================");
            System.out.println("\t1. EnQueue");
            System.out.println("\t2. DeQueue");
            System.out.println("\t3. DISPLAY");
            System.out.print("Enter your choice: ");
            System.out.println("\n========================");
            
            int choice = Integer.parseInt(in.nextLine());
            switch(choice)
            {
                case 1:
                    System.out.print("Element to be EnQueued: ");
                    int d = Integer.parseInt(in.nextLine());
                    obj.EnQ(d);
                    break;
                case 2:
                    try {
                        d = obj.DeQ();
                        System.out.println(d + " DeQueued");
                    } catch (IllegalStateException e) {
                        System.out.println("QUEUE IS EMPTY");
                    }
                    break;
                case 3:
                    obj.Show();
                    break;
                default:
                    System.out.println("Bye!");
                    return;
            }
            //obj.newEle();
            //obj.oldEle();
            
        }
    }
}
