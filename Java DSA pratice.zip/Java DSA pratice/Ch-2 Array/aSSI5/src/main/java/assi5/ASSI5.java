/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package assi5;

/**
 *
 * @author Siddiq Shah
 */
public class ASSI5 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
