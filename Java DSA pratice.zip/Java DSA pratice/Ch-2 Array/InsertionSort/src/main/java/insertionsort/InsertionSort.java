package insertionsort;

public class InsertionSort 
{
    // Method to print the array
    public static void printArray(int array[])
    {
        for (int i = 0; i < array.length; i++)
        {
            System.out.print(array[i] + " ");
        }
        System.out.println(); // Move to the next line after printing the array
    }
    
    public static void main(String[] args) 
    {
        //Insertion sort algo
        int array[] = {5,1,7,3,2,4};
        
        for(int i=0; i<array.length; i++)
        {
            int currentElement = array[i];
            int j = i-1;
            while(j>=0 && currentElement < array[j])
            {
                array[j+1] = array[j];
                j--;
            }
            array[j+1] = currentElement;
        }
         
        printArray(array);
    }
}
