/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package assi1;

public class MovieTicketQueue {
    public static void main(String[] args) {
        java.util.Scanner scanner = new java.util.Scanner(System.in);

        // Input: Number of queues
        System.out.print("Enter the number of queues: ");
        int n = scanner.nextInt();
        if (n <= 0) {
            System.out.println("Number of queues must be greater than 0.");
            return;
        }

        // Create and initialize the queues
        Queue[] queues = new Queue[n];
        for (int i = 0; i < n; i++) {
            queues[i] = new Queue();
            // Add at least 5 persons to each queue
            for (int j = 0; j < 5; j++) {
                queues[i].enqueue("Person " + (j + 1) + " in Queue " + (i + 1));
            }
        }

        System.out.println("Starting ticket processing...");
        int processedCount = 0;

        // Processing logic
        while (true) {
            boolean allEmpty = true;
            for (Queue queue : queues) {
                if (!queue.isEmpty()) {
                    allEmpty = false;
                    break;
                }
            }

            if (allEmpty) {
                break;
            }

            // Process from the last queue to the first
            for (int i = n - 1; i >= 0; i--) {
                if (!queues[i].isEmpty()) {
                    String person = queues[i].dequeue();
                    System.out.println("Processed: " + person);
                    processedCount++;

                    // Move the next person from the previous queue to this queue
                    if (i > 0 && !queues[i - 1].isEmpty()) {
                        String movedPerson = queues[i - 1].dequeue();
                        queues[i].enqueue(movedPerson);
                    }
                }
            }
        }

        System.out.println("All persons have been processed.");
        System.out.println("Total persons processed: " + processedCount);
    }
}
