/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assi1;

// Queue class implemented using a singly linked list
public class Queue {
    private Node front;
    private Node rear;

    public Queue() {
        this.front = null;
        this.rear = null;
    }

    // Enqueue a person into the queue
    public void enqueue(String data) {
        Node newNode = new Node(data);
        if (rear == null) {
            front = rear = newNode;
        } else {
            rear.next = newNode;
            rear = newNode;
        }
    }

    // Dequeue a person from the queue
    public String dequeue() {
        if (front == null) {
            return null; // Queue is empty
        }
        String data = front.data;
        front = front.next;
        if (front == null) {
            rear = null; // Queue becomes empty
        }
        return data;
    }

    // Check if the queue is empty
    public boolean isEmpty() {
        return front == null;
    }

    // Peek at the front of the queue
    public String peek() {
        return (front != null) ? front.data : null;
    }
}
