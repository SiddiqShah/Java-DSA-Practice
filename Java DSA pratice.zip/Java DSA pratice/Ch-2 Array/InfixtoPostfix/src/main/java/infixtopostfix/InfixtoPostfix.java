package infixtopostfix;

import java.util.*;
public class InfixtoPostfix 
{
    public static int Precedence(char ch)
    {
        switch(ch)
        {
            case '+':
            case '-':
                return 1;
            case '/':
            case '*':
                return 2;
            case '^':
                return 3;
            default:
                return -1;
        }
    }
    
    public static String IfinxTOpostfix(String Expression)
    {
        StringBuilder result = new StringBuilder();
        Stack<Character> stack = new Stack<>();
        
        for(int i=0; i<Expression.length(); i++)
        {
            char ch = Expression.charAt(i);
            
             // If character is an operand, add it to output
             if(Character.isLetterOrDigit(ch))
             {
                 result.append(ch);
             }
             
             // If character is '(', push it to the stack
             else if(ch == '(')
             {
                 stack.push(ch);
             }
             
             // If character is ')', pop and output until '(' is encountered
             else if(ch == ')')
             {
                 while(!stack.isEmpty() && stack.peek() != '(')
                 {
                     result.append(stack.pop());
                 }
                 stack.pop();
             }
             
             // If an operator
             else
             {
                 while(!stack.isEmpty() && Precedence(ch) <= Precedence(stack.peek()))
                 {
                     result.append(stack.pop());
                 }
                 stack.push(ch);
             }
        }
        // Pop all the operators from the stack
        while(!stack.isEmpty())
        {
            result.append(stack.pop());
        }
        return result.toString();
    }
    
    // main method
    public static void main(String[] args) 
    {
        Scanner keyboard = new  Scanner(System.in);
        
        // input an expression
        System.out.println("Input any expression:");
        String Expression = keyboard.nextLine();
        
        System.out.println("Infix Expression : "+Expression);
        System.out.println("Postfix Expression : "+IfinxTOpostfix(Expression));
    }
}
