package mergesortexample;

import java.util.Arrays;

public class MergeSortExample {

    // Main merge sort method
    public static void mergeSort(int[] array, int left, int right) {
        // Divide step: keep splitting the array until single elements remain
        if (left < right) {
            int middle = (left + right) / 2;

            // Print the array during the dividing step
            System.out.println("Dividing: " + Arrays.toString(Arrays.copyOfRange(array, left, right + 1)));

            // Recursively sort the left half
            mergeSort(array, left, middle);

            // Recursively sort the right half
            mergeSort(array, middle + 1, right);

            // Conquer step: merge the two halves after the recursive calls
            merge(array, left, middle, right);

            // Print the array during the conquering step
            System.out.println("Conquering: " + Arrays.toString(Arrays.copyOfRange(array, left, right + 1)));
        }
    }

    // Method to merge two sorted halves
    private static void merge(int[] array, int left, int middle, int right) {
        // Length of the two subarrays
        int leftSize = middle - left + 1;
        int rightSize = right - middle;

        // Temporary arrays for the left and right halves
        int[] leftArray = new int[leftSize];
        int[] rightArray = new int[rightSize];

        // Copy data to temporary arrays
        for (int i = 0; i < leftSize; i++) {
            leftArray[i] = array[left + i];
        }

        for (int j = 0; j < rightSize; j++) {
            rightArray[j] = array[middle + 1 + j];
        }

        // Initial indexes for subarrays and merged array
        int i = 0, j = 0, k = left;

        // Merging the subarrays back into the original array
        while (i < leftSize && j < rightSize) {
            if (leftArray[i] <= rightArray[j]) {
                array[k] = leftArray[i];
                i++;
            } else {
                array[k] = rightArray[j];
                j++;
            }
            k++;
        }

        // Copy remaining elements of the left subarray, if any
        while (i < leftSize) {
            array[k] = leftArray[i];
            i++;
            k++;
        }

        // Copy remaining elements of the right subarray, if any
        while (j < rightSize) {
            array[k] = rightArray[j];
            j++;
            k++;
        }
    }

    // Main function to test the merge sort
    public static void main(String[] args) {
        int[] array = {38, 27, 43, 3, 9, 82, 10};  // Sample array
        
        System.out.println("Before sorting:");
        System.out.println(Arrays.toString(array));
        
        // Call merge sort on the array
        mergeSort(array, 0, array.length - 1);
        
        System.out.println("After sorting:");
        System.out.println(Arrays.toString(array));
    }
}
