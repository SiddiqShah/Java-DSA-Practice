package quicksort;

public class QuickSort {
    public static void main(String[] args) {
        int[] array = {38, 27, 43, 3, 9, 82, 10};
        int key = 43; // The key we want to search for after sorting

        System.out.println("Original Array:");
        printArray(array);

        quickSort(array, 0, array.length - 1);

        System.out.println("Sorted Array:");
        printArray(array);

        // Perform linear search for the key
        int result = linearSearch(array, key);
        if (result != -1) {
            System.out.println("Key " + key + " found at index " + result);
        } else {
            System.out.println("Key " + key + " not found in the array.");
        }
        
        // Perform binary search for the key
        int result1 = binarySearch(array, key);
        if (result1 != -1) {
            System.out.println("Key " + key + " found at index " + result1);
        } else {
            System.out.println("Key " + key + " not found in the array.");
        }
    }

    // Quick Sort function
    public static void quickSort(int[] array, int low, int high) {
        if (low < high) {
            int pivotIndex = partition(array, low, high);
            quickSort(array, low, pivotIndex - 1);
            quickSort(array, pivotIndex + 1, high);
        }
    }

    // Partition function
    public static int partition(int[] array, int low, int high) {
        int pivot = array[high];
        int i = low - 1;

        for (int j = low; j < high; j++) {
            if (array[j] <= pivot) {
                i++;
                int temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
        }

        int temp = array[i + 1];
        array[i + 1] = array[high];
        array[high] = temp;

        return i + 1;
    }

    // Linear Search function
    public static int linearSearch(int[] array, int key) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] == key) {
                return i; // Return the index if the key is found
            }
        }
        return -1; // Return -1 if the key is not found
    }
    
     // Binary Search function
   public static int binarySearch(int[] array, int key) {
    int left = 0;
    int right = array.length - 1;

    while (left <= right) {
        int mid = left + (right - left) / 2;

        // If key is greater than mid element, move to the right half
        if (key > array[mid]) {
            left = mid + 1;
        }
        // If key is less than mid element, move to the left half
        else if (key < array[mid]) {
            right = mid - 1;
        }
        // If key is equal to mid element, return mid index
        else {
            return mid;
        }
    }
    
    return -1; // Key not found
}


    // Function to print an array
    public static void printArray(int[] array) {
        for (int value : array) {
            System.out.print(value + " ");
        }
        System.out.println();
    }
}
