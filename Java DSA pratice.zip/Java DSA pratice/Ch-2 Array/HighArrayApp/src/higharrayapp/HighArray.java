package higharrayapp;
public class HighArray 
{
    private long[] a;
    private int nEle;

    public HighArray(int max) 
    {
        a = new long[max];
        nEle = 0;
    }
    
    public boolean find(long searchKey)
    {
        int j;
        for(j=0; j<nEle; j++)
            if(a[j] == searchKey)
                break;
        if(j == nEle)
            return false;
        else
            return true;
    }
    
    public void insert(long value)
    {
        a[nEle] = value;
        nEle++;
    }
    
    public boolean delete(long value)
    {
        int j;
        for(j=0; j<nEle; j++)
            if(value == a[j])
               break;
        if(j==nEle)
            return false;
        else 
        {
            for (int k=j; k<nEle; k++)
                a[k] = a[k+1];
            nEle--;
            return true;
        }
    }
    
    public long getMax() {
        if (nEle == 0) {
            return -1; // Return -1 if the array is empty
        }
        long max = a[0];
        for (int i = 1; i < nEle; i++) {
            if (a[i] > max) {
                max = a[i];
            }
        }
        return max;
    }
    
  // New getMaxIndex method
    public int getMaxIndex() {
        if (nEle == 0) {
            return -1; // Return -1 if the array is empty
        }
        int maxIndex = 0;
        for (int i = 1; i < nEle; i++) {
            if (a[i] > a[maxIndex]) {
                maxIndex = i;
            }
        }
        return maxIndex;
    }
    
    // New method to get value at a specific index
    public long getValueAt(int index) {
        if (index >= 0 && index < nEle) {
            return a[index];
        } else {
            throw new ArrayIndexOutOfBoundsException("Index out of bounds");
        }
    }
    public void display()
    {
        for(int j=0; j<nEle; j++)
           System.out.println(a[j]+" ");
        System.out.println("");
    }
    
    
}












