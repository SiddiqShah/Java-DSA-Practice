package higharrayapp;

public class HighArrayApp {

    public static void main(String[] args) 
    {
        int maxSize = 100;
        HighArray arr = new HighArray(maxSize);
        
        arr.insert(77); // insert 10 items
        arr.insert(99);
        arr.insert(44);
        arr.insert(55);
        arr.insert(22);
        arr.insert(88);
        arr.insert(11);
        arr.insert(00);
        arr.insert(66);
        arr.insert(33);
        
        arr.display();
        
        int serachKey = 36;
        if(arr.find(serachKey))
            System.out.println("Search key FOund: "+serachKey);
        else
            System.out.println("Search key CAn't find: "+serachKey);
        
        System.out.println("\nArray after deleting some elements.");
        arr.delete(00);
        arr.delete(22);
        arr.delete(55);
        
        arr.display();
        
        // Test the getMax method
        long max = arr.getMax();
        if (max != -1) {
            System.out.println("The maximum value in the array is: " + max);
        } else {
            System.out.println("The array is empty.");
        }
        
        int maxIndex = arr.getMaxIndex();
        if (maxIndex != -1) {
            System.out.println("The maximum value in the array is: " + arr.getValueAt(maxIndex) + " at index " + maxIndex);
        } else {
            System.out.println("The array is empty.");
        }
        
    }
    
}

        