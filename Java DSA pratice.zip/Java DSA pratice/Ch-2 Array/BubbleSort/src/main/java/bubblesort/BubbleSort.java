package bubblesort;

public class BubbleSort 
{
    // Method to print the array
    public static void printArray(int array[])
    {
        for (int i = 0; i < array.length; i++)
        {
            System.out.print(array[i] + " ");
        }
        System.out.println(); // Move to the next line after printing the array
    }

    public static void main(String[] args) 
    {
        int array[] = {7, 8, 3, 2, 1};
        System.out.print("original array: ");
        printArray(array);
        System.out.println("");
        
        // time complexity = O(n^2)
        // Bubble sort
        for (int i = 0; i < array.length - 1; i++)
        {
            for (int j = 0; j < array.length - i - 1; j++)
            {
                // Compare adjacent elements and swap if necessary
                if (array[j] > array[j + 1]) 
                {
                    // Swap elements
                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                    
                    // Print the array after each swap
                    System.out.print("Array after comparing and swapping " + array[j + 1] + " and " + array[j] + ": ");
                    printArray(array);
                }
            }
            // Print the array after every outer loop iteration
            System.out.print("Array after iteration " + (i + 1) + ": ");
            printArray(array);
            System.out.println("");
        }
    }
}
