package queuedemo;

import java.util.Scanner;

public class MyQueue {
    private int[] queueArray = new int[5];
    private int front;
    private int rear;
    private int Size;
    //private int nItems;

    public void enQueue  (int data)
    {
        queueArray [rear] = data;
        rear++;
        Size++;
    }
    
    public int deQueue()
    {
        int data = queueArray[front];
        front++;
        Size--;
        return data;
    }
    
    public void show()
    {
        System.out.println("Elemets of queue : ");
        for(int i=0; i<Size; i++)
        {
            System.out.print(queueArray[front+i]+" ");
        }
        System.out.println();
        for(int n : queueArray)
        {
            System.out.print(n+" ");
        }
    }
}