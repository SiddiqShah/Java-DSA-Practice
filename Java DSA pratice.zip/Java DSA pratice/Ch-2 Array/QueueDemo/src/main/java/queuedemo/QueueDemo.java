package queuedemo;

public class QueueDemo {
    public static void main(String[] args) {
        MyQueue q = new MyQueue(); // Initialize the queue with size 5

        q.enQueue(1);
        q.enQueue(2);
        q.enQueue(6);
        q.enQueue(7);
        q.enQueue(4);

        q.show();

        q.deQueue();
        q.deQueue();

        q.show();

        q.enQueue(3);
        q.enQueue(9);

        q.show();
    }
}
