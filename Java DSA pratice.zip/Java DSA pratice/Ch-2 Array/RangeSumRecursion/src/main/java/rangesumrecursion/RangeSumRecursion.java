package rangesumrecursion;

public class RangeSumRecursion 
{
    public static void main(String[] args) 
    {
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        
        int start = 2;
        int end = 5;
        
        // Display the sum of elements in the specified range
        System.out.println("The sum of elements from index " + start + " to index " + end + 
                " is " + RangeSum(array, start, end));
    }
    
    public static int RangeSum(int Array[], int StartingElement, int EndingElement)
    {
        if (StartingElement > EndingElement) {
            return 0; // Base case: if starting index exceeds ending index
        } else {
            // Recursive call
            int sum = Array[StartingElement] + RangeSum(Array, StartingElement + 1, EndingElement);
            
            // Display the current state after the recursive call, showing both index and value
            System.out.println("Summing element at index " + StartingElement + " (value: " + 
                               Array[StartingElement] + "): Current sum is " + sum);
            
            return sum; // Return the sum after recursion
        }
    }
}
