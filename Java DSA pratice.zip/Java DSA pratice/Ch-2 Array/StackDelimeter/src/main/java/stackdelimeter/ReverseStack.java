package stackdelimeter;

import java.util.Stack;

public class ReverseStack 
{
    Stack<Integer> stack = new Stack<>();
    Stack<Integer> stack1= new Stack<>();
    String name = "Racecar";
    
    public void pilindrom()
    {
        char exp;
        for(int i = 0; i<name.length();i++)
        {
            stack.push(i);  
        }
        for(int i = 0; i<stack1.size();i++)
        {
            stack.pop();
            stack1.push(i);
            System.out.println("Stack 1 is "+stack1);
        }
        
        System.out.println("Stack 1 is "+stack1);
        
        
        
    }
        
    
}
