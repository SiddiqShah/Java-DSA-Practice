package stackdelimeter;

public class StackDelimeter 
{
    public static void main(String[] args) 
    {
//        DelimiterStack s = new DelimiterStack();
          ReverseStack s = new ReverseStack();
////        s.delemim();
//        s.FullDelem();

          s.pilindrom();
    }
}
