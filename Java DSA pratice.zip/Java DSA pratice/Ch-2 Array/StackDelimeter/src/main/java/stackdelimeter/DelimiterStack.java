
package stackdelimeter;

import java.util.Stack;

public class DelimiterStack 
{
    Stack<Integer> stack = new Stack<>();
    
    String seq = "{[(2+3)]}";
    
//    public void delemim()
//    {
//        char exp;
//        for(int i=0;i<seq.length();i++)
//        {
//            exp = seq.charAt(i);
//            if(exp == '(')
//            {
//                stack.push(i);
//            }
//            else if(exp == ')')
//            {
//                stack.pop();
//                if(stack.isEmpty())
//                {
//                    System.out.println("InValid case");
//                }
//            }
//            
//        }
//        
//           
//        if(stack.isEmpty())
//        {
//            System.out.println("Valid case");
//        }
//        else
//        {
//            System.out.println("InValid case from out of loop");
//        }
//            
//        
//    }
//    
    
    public void FullDelem()
    {
        char exp;
        for(int i=0;i<seq.length();i++)
        {
            exp = seq.charAt(i);
            if(exp == '{' || exp == '[' || exp == '(')
            {
                stack.push(i);
            }
            else if(exp == '}' || exp == ']' || exp == ')')
            {
                stack.pop();
                
            }
            
        }
        if(stack.isEmpty())
        {
            System.out.println("Valid case");
        }
       
    }
        
}
