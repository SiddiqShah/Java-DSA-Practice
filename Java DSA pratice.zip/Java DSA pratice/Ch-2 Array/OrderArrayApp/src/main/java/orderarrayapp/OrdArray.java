package orderarrayapp;

public class OrdArray 
{
    private long[] a;
    private int nEle;
    
    OrdArray(int max)
    {
        a = new long[max];
        nEle =0;
    }
    
    public int size()
    {
        return nEle;
    }
    
   public int find(long searchKey) 
   {
       int lowerBound = 0;
       int upperBound = nEle-1;
       int curIn;
       while(true)
    {
       curIn = (lowerBound + upperBound ) / 2;
       if(a[curIn]==searchKey)
           return curIn; // found it
       else if(lowerBound > upperBound)
           return nEle; // can’t find it
        else // divide range
        {
           if(a[curIn] < searchKey)
           lowerBound = curIn + 1; // it’s in upper half
        else
           upperBound = curIn - 1; // it’s in lower half
        } // end else divide range
    }
    }
   
   public void insert(long value) 
   {
    int j;
    
    // Find the position where the new value should be inserted
    for (j = 0; j < nEle; j++) 
    {
        if (a[j] > value) 
        {
            break;
        }
    }
    
    // Shift elements to the right to make space for the new value
    for (int k = nEle; k > j; k--) 
    {
        a[k] = a[k - 1];
    }
    
    // Insert the new value
    a[j] = value;
    
    // Increment the number of elements
    nEle++;
    }
   
   public boolean delete(long value)
   {
       int j = find(value);
       if(j == nEle)
           return false;
       else
       {
           for(int k=j; k<nEle; k++)
               a[k] = a[k+1];
           nEle--;
           return true;
       }
   }
   
    public void display() // displays array contents
    {
       for(int j=0; j<nEle; j++) // for each element,
       System.out.print(a[j] + " "); // display it
       System.out.println("");
}
  }
