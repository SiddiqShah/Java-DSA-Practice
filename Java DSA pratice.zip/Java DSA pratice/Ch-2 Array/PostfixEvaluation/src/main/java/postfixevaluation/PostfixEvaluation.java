package postfixevaluation;

import java.util.*;

public class PostfixEvaluation {

    // Method to evaluate a postfix expression
    public static int evaluatePostfix(String expression) {
        Stack<Integer> stack = new Stack<>();
        
        for (int i = 0; i < expression.length(); i++) {
            char ch = expression.charAt(i);

            // If the character is a digit, push it to the stack
            if (Character.isDigit(ch)) {
                stack.push(ch - '0'); // Convert char to int
            } else {
                // Pop the top two elements from the stack for the operation
                int operand1 = stack.pop();
                int operand2 = stack.pop();

                switch (ch) {
                    case '+':
                        stack.push(operand2 + operand1);
                        break;
                    case '-':
                        stack.push(operand2 - operand1);
                        break;
                    case '*':
                        stack.push(operand2 * operand1);
                        break;
                    case '/':
                        stack.push(operand2 / operand1);
                        break;
                    default:
                        break;
                }
            }
        }

        // The final result will be the only element left in the stack
        return stack.pop();
    }

    // Main method
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);

        // Input a postfix expression
        System.out.println("Enter a postfix expression:");
        String expression = keyboard.nextLine();

        System.out.println("Postfix Expression: " + expression);
        System.out.println("Postfix Evaluation: " + evaluatePostfix(expression));
    }
}
