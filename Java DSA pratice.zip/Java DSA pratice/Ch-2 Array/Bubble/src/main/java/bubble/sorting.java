
package bubble;

import java.util.Arrays;

public class sorting 
{
    int arr[]={5,4,6,7,2,3,4,8,5,2,8,5,6,3,2,34,65};
    
    public void sort()
    {
        int temp;
        for(int i=0;i<arr.length-1;i++)
        {
            for(int j=0;j<arr.length-i-1;j++)
            {
                if(arr[j]>arr[j+1])
                {
                    temp=arr[j];
                    arr[j]=arr[j+1];
                    arr[j+1]=temp;
                }
            }
        }   
        System.out.println(Arrays.toString(arr));
    }

    
    
}
