

package bubble;

public class Bubble {

    public static void main(String[] args) 
    {
        sorting s = new sorting();
        s.sort();
    }
}
