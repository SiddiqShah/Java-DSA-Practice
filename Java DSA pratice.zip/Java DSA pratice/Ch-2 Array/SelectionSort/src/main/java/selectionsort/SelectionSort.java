package selectionsort;

public class SelectionSort 
{
    // Method to print the array
    public static void printArray(int array[]) 
    {
        for (int i = 0; i < array.length; i++)
        {
            System.out.print(array[i] + " ");
        }
        System.out.println(); // Move to the next line after printing the array
    }
    
    public static void main(String[] args) 
    {
        int array[] = {6, 8, 2, 3, 4, 9};

        // Print the original array
        System.out.print("Original array: ");
        printArray(array);
        
        // Selection sort
        for (int i = 0; i < array.length; i++)
        {
            int smallestValue = i;

            // Find the index of the smallest value
            for (int j = i + 1; j < array.length; j++)
            {
                if (array[smallestValue] > array[j])
                    smallestValue = j;
            }

            // Swap if the smallest value is not the current position
            if (smallestValue != i) 
            {
                System.out.println("Swapping " + array[i] + " and " + array[smallestValue]);
                int temp = array[smallestValue];
                array[smallestValue] = array[i];
                array[i] = temp;
            }
        }

        // Print the sorted array
        System.out.print("Sorted array: ");
        printArray(array);
    }
}
