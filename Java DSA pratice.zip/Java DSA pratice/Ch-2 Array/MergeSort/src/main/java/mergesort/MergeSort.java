package mergesort;

public class MergeSort {
    public static void main(String[] args) {
        int[] array = {38, 27, 43, 3, 9, 82, 10, 12};
        System.out.println("Original Array:");
        printArray(array);

        mergeSort(array, 0, array.length - 1);

        System.out.println("Sorted Array:");
        printArray(array);
    }

    // Merge Sort Function
    public static void mergeSort(int[] array, int left, int right) {
        if (left < right) {  // Base case: stop when left is not less than right
            int mid = (left + right) / 2;

            // Recursively sort the first and second halves
            mergeSort(array, left, mid);
            mergeSort(array, mid + 1, right);

            // Merge the sorted halves
            merge(array, left, mid, right);
        }
    }

    // Merge Function
    // Merge Function with single temporary array
public static void merge(int[] array, int left, int mid, int right) {
    // Calculate the sizes of the two subarrays
    int subArraySize = right - left + 1;

    // Create a single temporary array to hold the merged subarrays
    int[] tempArray = new int[subArraySize];

    int i = left;       // Starting index for the left subarray
    int j = mid + 1;    // Starting index for the right subarray
    int k = 0;          // Index for the tempArray

    // Merge the two subarrays into tempArray
    while (i <= mid && j <= right) {
        if (array[i] <= array[j]) {
            tempArray[k++] = array[i++];
        } else {
            tempArray[k++] = array[j++];
        }
    }

    // Copy any remaining elements from the left subarray
    while (i <= mid) {
        tempArray[k++] = array[i++];
    }

    // Copy any remaining elements from the right subarray
    while (j <= right) {
        tempArray[k++] = array[j++];
    }

    // Copy the sorted elements back into the original array
    for (int m = 0; m < subArraySize; m++) {
        array[left + m] = tempArray[m];
    }
}


    // Function to print an array
    public static void printArray(int[] array) {
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");
        }
        System.out.println();
    }
}
