package classdataarrayapp;

public class ClassDataArrayApp 
{
    public static void main(String[] args) 
    {
        int maxSize = 100; // array size
ClassDataArray arr; // reference to array
arr = new ClassDataArray(maxSize); // create the array
// insert 10 items
arr.insert("Shah", "Siddiq", 20);
        arr.insert("Afridi", "Ashir", 19);
        arr.insert("Khan", "Adil", 22);
        arr.insert("Khan", "Daud", 20);
        arr.insert("Mustafa", "Muhammad", 21);
        arr.insert("Ullah", "Haseeb", 23);
        arr.insert("Shah", "Munib", 26);
        arr.insert("Shah", "Mujib", 23);
        arr.insert("Shah", "Fazal", 31);
        
        arr.displayA(); // display items
        
        String searchKey = "Mustafa"; // search for item
        Person found;
        
        found=arr.find(searchKey);
        if(found != null)
        {
            System.out.print("Found ");
            found.displayPerson();
        }
        else
            System.out.println("Can’t find " + searchKey);
    }
}
