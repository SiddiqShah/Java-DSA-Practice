package intersection4;

import java.util.Scanner;

public class Intersection4 {

    public static void main(String[] args) 
    {
        Scanner scanner = new Scanner(System.in);

        // Create first linked list
        System.out.println("Enter values for the first list (end with -1):");
        Node head1 = null, tail1 = null;
        while (true) {
            int value = scanner.nextInt();
            if (value == -1) break;
            Node newNode = new Node(value);
            if (head1 == null) {
                head1 = tail1 = newNode;
            } else {
                tail1.next = newNode;
                tail1 = newNode;
            }
        }

        // Create second linked list
        System.out.println("Enter values for the second list (end with -1):");
        Node head2 = null, tail2 = null;
        while (true) {
            int value = scanner.nextInt();
            if (value == -1) break;
            Node newNode = new Node(value);
            if (head2 == null) {
                head2 = tail2 = newNode;
            } else {
                tail2.next = newNode;
                tail2 = newNode;
            }
        }

        // Create an intersection manually for testing purposes
        System.out.println("Enter the position of intersection in the first list (0 for no intersection):");
        int intersectionPos = scanner.nextInt();

        if (intersectionPos > 0) {
            Node current = head1;
            int currentPos = 1;
            while (current != null && currentPos < intersectionPos) {
                current = current.next;
                currentPos++;
            }

            if (current != null) {
                tail2.next = current; // Create intersection
            } else {
                System.out.println("Invalid intersection position. No intersection created.");
            }
        }

        IntersectionNode intersectionFinder = new IntersectionNode();

        // Print both linked lists
        System.out.print("List 1: ");
        intersectionFinder.printList(head1);
        System.out.print("List 2: ");
        intersectionFinder.printList(head2);

        // Find intersection
        Node intersection = intersectionFinder.intersectionNode(head1, head2);

        if (intersection != null) {
            System.out.println("Intersection at node with value: " + intersection.data);

            // Print values after the intersection
            System.out.print("Values after intersection: ");
            Node current = intersection;
            while (current != null) {
                System.out.print(current.data + " -> ");
                current = current.next;
            }
            System.out.println("null");

        } else {
            System.out.println("No intersection found.");
        }

        scanner.close();
    }
}
