package insertionsort2;

public class InsertionSort2
{
    // Method to print the array
    public static void printArray(int array[])
    {
        for (int i = 0; i < array.length; i++)
        {
            System.out.print(array[i] + " ");
        }
        System.out.println(); // Move to the next line after printing the array
    }
    
    public static void main(String[] args) 
    {
        // Insertion sort algorithm
        int array[] = {5, 1, 7, 3, 2, 4};
        
        // Insertion Sort logic
        for (int i = 1; i < array.length; i++)  // Start from 1 (not 0)
        {
            int currentElement = array[i];  // The element to be inserted
            int j = i - 1;
            // Find the correct position for currentElement
            while (j >= 0 && currentElement < array[j]) 
            {
                array[j + 1] = array[j];  // Shift elements to the right
                j--;
            }
            array[j + 1] = currentElement;  // Insert the element at the correct position
            
            // Print the array after each iteration of the outer loop
            System.out.println("Array after iteration " + i + ":");
            printArray(array);
        }
        
        // Final sorted array
        System.out.println("Sorted array:");
        printArray(array);
    }
}
