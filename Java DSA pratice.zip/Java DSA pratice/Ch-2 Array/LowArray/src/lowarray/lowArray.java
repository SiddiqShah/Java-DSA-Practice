package lowarray;

public class lowArray 
{
    private long[] arr;
    
    public lowArray(int size)
    {
        arr = new long[size];
    }
    
    public void setElement(int index, long value)
    {
        arr[index] = value;
    }
    public long getElement(int index)
    {
        return arr[index];
    }
    // end class.
}
