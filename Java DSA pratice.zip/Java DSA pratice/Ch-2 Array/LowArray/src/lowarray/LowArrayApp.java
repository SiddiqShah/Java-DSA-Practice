package lowarray;

public class LowArrayApp {

    public static void main(String[] args) 
    {
        lowArray a = new lowArray(100);
        int nElements = 0;
        int j;
        
        a.setElement(0, 1);
        a.setElement(1, 2);
        a.setElement(2, 3);
        a.setElement(3, 4);
        a.setElement(4, 5);
        a.setElement(5, 6);
        a.setElement(6, 7);
        a.setElement(7, 8);
        a.setElement(8, 9);
        a.setElement(9, 10);
        
        nElements = 10;
        
        // display the items
        System.out.println("**********************************");
        for(j=0; j<nElements; j++)
            System.out.print(a.getElement(j)+" ");
        System.out.println("**********************************");
        
        
        // seach for an item
        System.out.println("**********************************");
        int searchKey = 8;
        for(j=0; j<nElements; j++)
            if(a.getElement(j) == searchKey)
                break;
        if(j == nElements)
            System.out.println("Cant find seach key: "+searchKey);
        else
            System.out.println("Found search key: "+searchKey);
        System.out.println("**********************************");
        
        //deleting value 
        searchKey = 7;
        for(j=0; j<nElements; j++)
            if(a.getElement(j) == searchKey)
                break;
        for(int k=j; k<nElements; k++)
            a.setElement(k, a.getElement(k+1));
        nElements--;
        
        // display the items
        System.out.println("**********************************");
        for(j=0; j<nElements; j++)
            System.out.print(a.getElement(j)+" ");
        System.out.println(" ");
        System.out.println("**********************************");
    }
    
}


