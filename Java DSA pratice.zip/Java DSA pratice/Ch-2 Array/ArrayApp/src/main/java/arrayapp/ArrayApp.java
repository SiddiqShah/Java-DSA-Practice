package arrayapp;

import java.util.Scanner;

public class ArrayApp {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        char choice;

        do {
            long[] arr = new long[100];
            int numElements = 0;

            int j;
            long searchKey;

            arr[0] = 77; // insert 10 items
            arr[1] = 99;
            arr[2] = 44;
            arr[3] = 55;
            arr[4] = 22;
            arr[5] = 88;
            arr[6] = 11;
            arr[7] = 0;
            arr[8] = 66;
            arr[9] = 33;
            numElements = 10; // now 10 items in array

            for (j = 0; j < numElements; j++) {
                System.out.print(arr[j] + " ");
            }
            System.out.println();

            System.out.println("Enter an item number to search: ");
            searchKey = input.nextLong();
            boolean found = false;
            for (j = 0; j < numElements; j++) { // for each element
                if (arr[j] == searchKey) { // find item?
                    found = true;
                    break;
                }
            }
            if (found) {
                System.out.println("Found " + searchKey);
            } else {
                System.out.println("Can't find " + searchKey);
            }

            for (j = 0; j < numElements; j++) { // display items
                System.out.print(arr[j] + " ");
            }
            System.out.println();

            System.out.println("Do you want to run the program again? (Y/N): ");
            choice = input.next().charAt(0);
        } while (choice == 'Y' || choice == 'y');

        input.close();
    }
}
