package salesapp;

public class SalesApp 
{
    public static void main(String[] args) 
    {
        Sales s1 = new Sales();
        s1.salesInput();
        s1.display();

        s1.highSale();
        s1.lowSalee();
        s1.Average();
    }
}
