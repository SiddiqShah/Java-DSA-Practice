package salesapp;

import java.util.Random;

public class Sales 
{
    float salesRec[];
    String[] months = {"January", "February", "March", "April", "May", "June",
                       "July", "August", "September", "October", "November", "December" };
    
    Sales()
    {
        salesRec = new float[12];
    }
    
    public void salesInput()
    {
        Random rand = new Random();
        int min = 500;
        int max = 1000;
        System.out.println("Randomly Sales of the year.");
        for(int i=0; i<salesRec.length; i++)
        {
            salesRec[i] = rand.nextInt(max-min+1) + min;
        }
    }
    
    public float highSale() {
    float maxSale = salesRec[0];
    int maxMonthIndex = 0;

    for (int i = 0; i < salesRec.length; i++) {
        if (salesRec[i] > maxSale) {
            maxSale = salesRec[i];
            maxMonthIndex = i;
        }
    }

    System.out.println("The highest sale is in " + months[maxMonthIndex] + " with a value of " + maxSale);
    return maxSale;
}
    
    public float lowSalee()
    {
        float minSale = salesRec[0];
        int minMonthIndex = 0;
        for(int i=0; i<salesRec.length; i++)
        {
            if(salesRec[i]<minSale)
            {
                minSale = salesRec[i];
                minMonthIndex = i;
            }
        }
         System.out.println("The lowest sale is in " + months[minMonthIndex] + " with a value of " + minSale);
            return minSale;
    }
    
    public float Average()
            {
                float avg = 0.0f;
                float sum =0.0f;
                for(int i=0; i<salesRec.length; i++)
                {
                    sum += salesRec[i];
                }
                avg = sum / 12;
                System.out.println("The avg Sale is "+avg);
                return avg;
            }

    
    public void display()
    {
        for(int i=0; i< salesRec.length; i++)
        {
            System.out.println(months[i]+" : "+salesRec[i]);
        }
    }
    
}
