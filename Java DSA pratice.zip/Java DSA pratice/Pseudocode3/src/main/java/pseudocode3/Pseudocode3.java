package pseudocode3;

public class Pseudocode3 
{
    public static void main(String[] args) 
    {
        int sum, i;
        
        sum = 0;
        
        for (i = 1; i <= 10; i++)
        {
            sum += i; // Add i to sum
        }
        System.out.println("Sum of 1 to 10 is : " + sum);
    }
}
