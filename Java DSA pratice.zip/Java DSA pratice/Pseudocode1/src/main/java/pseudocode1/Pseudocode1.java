package pseudocode1;

import java.util.Scanner;

public class Pseudocode1 
{
    public static void main(String[] args) 
    {
        float height, width, length, volume;
        
        Scanner input = new Scanner(System.in);
        
        System.out.println("Enter height:");
        height = input.nextInt();
        
        System.out.println("Enter width:");
        width = input.nextInt();
        
        System.out.println("Enter length:");
        length = input.nextInt();
        
        
        volume = height * width * length;
        
        System.out.println("The volume is: "+volume);
    }
}
