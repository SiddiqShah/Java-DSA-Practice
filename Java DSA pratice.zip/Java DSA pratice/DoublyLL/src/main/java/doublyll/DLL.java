package doublyll;

/**
 * Doubly Linked List implementation
 */
public class DLL {
    node head; // Pointer to the head of the list
    int size;  // Size of the list (number of nodes)

    // Constructor to initialize an empty list
    public DLL() {
        head = null;
        size = 0;
    }

    // Insert a node at the start of the list
    public void insertStart(int data) {
        node newNode = new node(data); // Create a new node
        size++; // Increment the size

        if (head == null) {
            head = newNode; // If the list is empty, the new node is the head
        } else {
            newNode.next = head;       // Point the new node's next to the current head
            head.previous = newNode;  // Update the current head's previous to the new node
            head = newNode;           // Update the head to the new node
        }
        System.out.println(data + " inserted at the start successfully.");
    }
    
    // Insert a node at the END of the list
    void insertLast(int data) {
        
    }

    // Display the doubly linked list
    public void display() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        node temp = head;
        System.out.print("Doubly Linked List: ");
        while (temp != null) {
            System.out.print(temp.data + " <-> ");
            temp = temp.next;
        }
        System.out.println("null");
    }
}
