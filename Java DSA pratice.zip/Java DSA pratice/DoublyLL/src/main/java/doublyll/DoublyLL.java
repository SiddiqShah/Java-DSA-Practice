package doublyll;

/**
 *
 * @author Siddiq Shah
 */
public class DoublyLL {

    public static void main(String[] args) {
        DLL L = new DLL();

        // Insert elements at the start of the doubly linked list
        L.insertStart(1);
        L.insertStart(2);
        L.insertStart(3);
        L.insertStart(4);

        // Display the list
        L.display();

        // Display the size of the list
        System.out.println("Size of DLL: " + L.size);
    }
}
