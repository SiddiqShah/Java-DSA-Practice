/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package doublyll;

/**
 *
 * @author Siddiq Shah
 */
public class node {
    int data;
    node next;
    node previous;
    
    node(int data){
        this.data = data;
        this.next = null;
        this.previous = null;
    }
    
}
