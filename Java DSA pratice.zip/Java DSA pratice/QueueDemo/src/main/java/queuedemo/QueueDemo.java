package queuedemo;
import java.util.*;
public class QueueDemo 
{
    public static void main(String[] args) 
    {
        String str;
        
        Scanner kb = new Scanner(System.in);
        
        System.out.println("Enter the size of the queue:");
        int capacity = kb.nextInt();
        
        ArrayQueue queue = new ArrayQueue(capacity);
        str = "Queue has capacity : ";
        System.out.println(str + queue.capacity());
        
        System.out.println("Add items (separated by spaces):");
        kb.nextLine(); // Consume leftover newline
        String inputLine = kb.nextLine();
        String[] names = inputLine.split(" "); // Split the line into an array of strings
        System.out.println("Adding names: "); 
        for(String s : names )        
        {
            System.out.println(s+" ");
            queue.enQ(s);
        }
        System.out.println("\nState of Queue is: ");
        System.out.println(queue);
                
        // Remove 2 names
        System.out.println("\nremoving two names");
        queue.deQ();
        queue.deQ();
//        
        System.out.println("state of queue:");
        System.out.println(queue);
//        
        // add  a name
        System.out.println("\nAdding name Yaman:");
        queue.enQ("Yaman");
        System.out.println(queue);

        
    }
}
