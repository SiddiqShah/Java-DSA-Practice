package queuedemo;
import java.util.*;
public class ArrayQueue 
{
    private String[] queue;
    int size, front, rear;

    public ArrayQueue(int capacity)
    {
        queue = new String[capacity];
        front = 0;
        rear = 0;
        size = 0;
    }
    
    // return length
    public int capacity()
    {
        return queue.length;
    }
    
    public void enQ(String Data)
    {
       queue [rear] = Data;
        rear++;
        size++;
        
        if(rear == queue.length) 
            rear = 0;
    }
    
    public String peek()
    {
        return queue[front];
    }
    
    public String deQ()
    {
        String value = queue[front];
        size --;
        
        // facillitate carbage collection
        queue[front] = null;
        
        // 
        front++;
        
        if(front == queue.length)
            front = 0;
        
        return value;
    }
    
    public boolean empty()
    {
        return size == 0 ;
    }
    
     /**
 118        The toString method returns a
 119        readable representation of the
 120        contents of the queue.
 121        @return  The string representation
 122        of the contents of the queue.
 123     */
    
    public String toString()
    {
        StringBuilder sBuilder = new StringBuilder();
        sBuilder.append("Front = "+front+ ": ");
        sBuilder.append("Rear "+rear+"\n");
        
        for(int k=0; k<queue.length; k++)
        {
            if (queue[k] != null)
            {
                sBuilder.append(k + " "+ queue[k]);
            }
            else
            {
                sBuilder.append(k+ " ?");
            }
            if(k != queue.length-1)
                sBuilder.append("\n");
        }
        
        return sBuilder.toString();
                
    }
}
