package queue;

public class MyQueue 
{
    int queue[];
    int front, rear, size = 0;

    public MyQueue(int size) 
    {
        queue = new int[size];
        front = 0;
        rear = 0;
    }
    
    boolean isEmpty()
    {
        return size == 0;
    }
    
    boolean isFull()
    {
        return size == queue.length;
    }
    
    public void EnQ(int data)
    {
        if(isFull()) 
        {
            System.out.println("Queue is full.");
        } 
        else 
        {
            queue[rear] = data;
            rear = (rear + 1) % queue.length;  // Circular increment
            size++;  // Increment size
        }
    }
    
    public void DeQ()
    {
        if (!isEmpty())  // Check if the queue is not empty
        {
            int value = queue[front];
            System.out.println("Dequeued value: " + value);
            front = (front + 1) % queue.length;  // Circular increment
            size--;  // Decrement size
        } 
        else 
        {
            System.out.println("Queue is Empty.");
        }
    }
    
    public void peek()
    {
        if (!isEmpty()) 
        {
            System.out.println("The peek element is: " + queue[front]);
        } 
        else 
        {
            System.out.println("Queue is Empty.");
        }
    }
    
// Method to reverse the first five elements and arrange them in ascending order
//       public void reverseFirstFive() 
//    {
//        if (size < 5) 
//        {
//            System.out.println("Queue doesn't have enough elements to reverse first five.");
//            return;
//        }
//
//        // Perform sorting of first five elements using a single loop and basic sorting logic
//        for (int i = 0; i < 5 - 1; i++) 
//        {
//            for (int j = i + 1; j < 5; j++) 
//            {
//                int firstIdx = (front + i) % queue.length;
//                int secondIdx = (front + j) % queue.length;
//
//                // Swap if elements are out of order
//                if (queue[firstIdx] > queue[secondIdx]) 
//                {
//                    int temp = queue[firstIdx];
//                    queue[firstIdx] = queue[secondIdx];
//                    queue[secondIdx] = temp;
//                }
//            }
//        }
//    }    
//    public void check()
//    {
//        if(queue[front] < queue[front+1])
//        {
//            /* Since 6 is NOT less than 5, the condition evaluates to false, 
//            and the block of code inside this if statement will not execute.What Happens:
//            The program skips the rest of the method and does not check for consecutiveness.
//            No output will be printed.
//            */
//            int i = queue[front];
//            i++;
//            
//            if(queue[front+1] == i)
//                System.out.println("condective");
//            else
//                System.out.println("not cons");
//        }
//        else
//            System.out.println("not consective");
//    }
//
//    // New method to print the queue
    public void printQueue()
    {
        if (isEmpty()) 
        {
            System.out.println("Queue is empty.");
        } 
        else 
        {
            System.out.print("Queue contents: ");
            for (int i = 0; i < size; i++) 
            {
                System.out.print(queue[(front + i) % queue.length] + " ");
            }
            System.out.println();
        }
    }

//    // Method to check if the elements are in consecutive order
//    public void checkConsecutive()
//    {
//        boolean consecutive = true;
//        for (int i = 0; i < size - 1; i++) 
//        {
//            if (queue[(front + i) % queue.length] + 1 != queue[(front + i + 1) % queue.length]) 
//            {
//                consecutive = false;
//                break;
//            }
//        }
//
//        if (consecutive) 
//        {
//            System.out.println("The elements are in consecutive order.");
//        } 
//        else 
//        {
//            System.out.println("The elements are NOT in consecutive order.");
//        }
//    }
//
//    // Method to check if the queue is in ascending or descending order
//    public void checkOrder()
//    {
//        if (isEmpty() || size == 1) 
//        {
//            System.out.println("Not enough elements to determine order.");
//            return;
//        }
//
//        boolean ascending = true;
//        boolean descending = true;
//
//        for (int i = 0; i < size - 1; i++) 
//        {
//            if (queue[(front + i) % queue.length] >= queue[(front + i + 1) % queue.length]) 
//            {
//                ascending = false;
//            }
//            if (queue[(front + i) % queue.length] <= queue[(front + i + 1) % queue.length]) 
//            {
//                descending = false;
//            }
//        }
//
//        if (ascending) 
//        {
//            System.out.println("The elements are in ascending order.");
//        } 
//        else if (descending) 
//        {
//            System.out.println("The elements are in descending order.");
//        } 
//        else 
//        {
//            System.out.println("The elements are neither in ascending nor descending order.");
//        }
//    }
}

