package queue;

public class Queue 
{
    public static void main(String[] args) 
    {
        MyQueue q = new MyQueue(10);
       q.EnQ(10);
        q.EnQ(20);
        q.EnQ(5);
        q.EnQ(15);
        q.EnQ(30);
        q.EnQ(25);
        q.EnQ(40);
        q.EnQ(50);
        q.EnQ(35);
        q.EnQ(60);
        
        q.printQueue();
        
        q.DeQ();
        q.printQueue();
         // Print the initial queue contents
       // System.out.println("Before reverse:");
       // q.printQueue();  // Prints all elements

        //System.out.println("check consetivenes");
       // q.check();
        //System.out.println("");
        
         //Reverse the first five elements
         //q.reverseFirstFive();

        // Print the queue contents after sorting the first five elements
      //  System.out.println("After reverse of first five elements:");
       // q.printQueue();  // Should print the first five elements sorted in ascending order
    }
}
