/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tree;

/**
 *
 * @author Siddiq Shah
 */
public class Node {
    int data;
    Node left;
    Node right;
    
    Node(int d) {
        data = d;
        left = null;
        right = null;
    }
            
}
