package tree;

/**
 *
 * @author Siddiq Shah
 */
public class Tree {

    public static void main(String[] args) {
         int[] nodes = {1,2,4,-1,-1,5,-1,-1,3,-1,6,-1,-1};
         
         BinaryTree BT = new BinaryTree();
         
         Node root = BT.buildTree(nodes);
         System.out.println("pre order traversal.");
         BT.preordertraversal(root);
         System.out.println("in order traversal.\n\n");
         BT.inordertraversal(root);
         System.out.println("Post order traversal.\n\n");
         BT.postordertraversal(root);
//         System.out.println(root.data);
    }
}
