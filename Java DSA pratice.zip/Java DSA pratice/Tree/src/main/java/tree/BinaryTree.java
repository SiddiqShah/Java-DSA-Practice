/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tree;

/**
 *
 * @author Siddiq Shah
 */
public class BinaryTree {
    
    int idx = -1;
    
    Node buildTree(int[] nodes) {
        idx++;
        
        if(nodes[idx] == -1) {
            return null;
        }
        
        Node n = new Node(nodes[idx]);
        n.left = buildTree(nodes);
        n.right = buildTree(nodes);
        
        return n;
    }
    
    void preordertraversal(Node root) {
        if(root == null) {
            System.out.println("tree is empty");
            return;
        }
        
        System.out.println(root.data+" ");
        preordertraversal(root.left);
        preordertraversal(root.right);
    }
    
    void inordertraversal(Node root) {
        if(root == null) {
            System.out.println("tree is empty");
            return;
        }
        preordertraversal(root.left);
        System.out.println(root.data+" ");
        preordertraversal(root.right);
    }
    
    void postordertraversal(Node root) {
        if(root == null) {
            System.out.println("tree is empty");
            return;
        }
        preordertraversal(root.left);
        preordertraversal(root.right);
        System.out.println(root.data+" ");

    }
}
