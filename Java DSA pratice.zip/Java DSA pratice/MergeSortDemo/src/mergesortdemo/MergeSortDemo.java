/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mergesortdemo;
import java.util.Scanner;

/**
 *
 * @author INAM
 */
public class MergeSortDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter List Size : ");
        int n = sc.nextInt();
        MergeApp mrg = new MergeApp(n);
        System.out.println("Original List!");
        mrg.showList();
        mrg.MergeSort(0, n-1);
        
        System.out.println("\n\nList after Merge Sort....!");
        mrg.showList();
    }
    
}
