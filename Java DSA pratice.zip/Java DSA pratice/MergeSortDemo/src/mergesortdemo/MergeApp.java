/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mergesortdemo;

import java.util.Random;

/**
 *
 * @author INAM
 */
public class MergeApp 
{
    int List[];
       
    public MergeApp(int N)
    {
        List = new int[N];
        
        Random r = new Random();
        for(int i=0; i < List.length; i++)
        {
            List[i] = (int)(Math.random()*20);
        }
        System.out.println("List Populated.......");
    }
    
    public void showList()
    {
        for(int i=0; i < List.length; i++)
        {
            System.out.print(List[i]+",");;
        }
        System.out.println("\n");
    }
    
    public void MergeSort(int lo, int hi)
    {
        int mid;
        if(lo < hi)
	{
            mid = (int)(lo + hi)/ 2;
            MergeSort(lo, mid);
            MergeSort(mid+1, hi);
            ListMerger(lo, mid, hi);
        }
    }
    
    public void ListMerger(int lo, int  mid, int hi)
    {   
        int[] TempList = new int[hi-lo+1];						//temporary merger array
        int i = lo, j = mid + 1;	//i is for left-hand,j is for right-hand
        int k = 0;									//k is for the temporary array
        while(i <= mid && j <=hi)
        {
            if(List[i] <= List[j])
            {
                TempList[k] = List[i++];
            }
            else
            {
                TempList[k] = List[j++];
            }
            k++;
        }

        //remaining elements of left-half
        while(i <= mid)
            TempList[k++] = List[i++];

        //remaining elements of right-half
        while(j <= hi)
            TempList[k++] = List[j++];

        //copy the mergered temporary List to the original List
        for(k = 0, i = lo; i <= hi; i++, ++k)
            List[i] = TempList[k];
        
        
        
 
    }
    
}
