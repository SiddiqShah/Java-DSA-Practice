package singlylinkedlist;

public class SinglyLinkedList 
{
    public static void main(String[] args) 
    {
         Node linkedList = new Node(0); // This is just a dummy node

        // Add elements to the linked list
        linkedList.add(10);
        linkedList.add(20);
        linkedList.add(30);
        linkedList.add(40); 

        // Display the linked list
        linkedList.display();
        
        linkedList.remove(20);

        // Display the list after removal
        linkedList.display();

        // Try removing a non-existent node
        linkedList.remove(50);

        // Remove the head node
        linkedList.remove(10);

        // Display the final state of the list
        linkedList.display();
    }
}
