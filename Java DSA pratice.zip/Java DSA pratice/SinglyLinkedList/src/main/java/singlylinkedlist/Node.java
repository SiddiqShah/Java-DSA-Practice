package singlylinkedlist;

public class Node 
{
    int data;
    Node next;
    
    Node(int data)
    {
        this.data = data;
        next = null;
    }
    
    // Define head and tail;
    public Node Head;
    public Node Tail;
    
    public void add(int data)
    {
        // create new node
        Node newNode = new Node(data);
        
        // check list is empty
        if(Head == null)
        {
            Head = newNode;
            Tail = newNode;
        }
        else
        {
            Tail.next = newNode;
            Tail = newNode;
        }
    }
    
    // Method to remove a node by value
    public void remove(int value) {
        // If the list is empty
        if (Head == null) {
            System.out.println("List is empty, nothing to remove.");
            return;
        }

        // If the node to be removed is the head
        if (Head.data == value) {
            Head = Head.next;
            System.out.println("Node with value " + value + " removed.");
            return;
        }

        // Traverse the list to find the node to be removed
        Node current = Head;
        Node previous = null;

        while (current != null && current.data != value) {
            previous = current;
            current = current.next;
        }

        // If the value is not found
        if (current == null) {
            System.out.println("Node with value " + value + " not found.");
            return;
        }

        // Remove the node
        previous.next = current.next;

        // Update the tail if the last node was removed
        if (current == Tail) {
            Tail = previous;
        }

        System.out.println("Node with value " + value + " removed.");
    }
    
    public void display()
    {
        Node current = Head;
        
        if(Head == null)
        {
            System.out.println("List is empty");
            return;
        }
        System.out.println("Nodes of Singly Linked List.");
        while(current != null)
        {
            System.out.print(current.data+" ");
            current = current.next;
        }
        System.out.println();
    }
}
