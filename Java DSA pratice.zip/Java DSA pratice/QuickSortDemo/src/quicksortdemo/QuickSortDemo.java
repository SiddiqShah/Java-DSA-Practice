package quicksortdemo;
import java.util.Scanner;


public class QuickSortDemo 
{

    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter List Size : ");
        int n = sc.nextInt();
        QuickApp quick = new QuickApp(n);
        System.out.println("Original List!");
        quick.showList();
        quick.QuickSort(0, n-1);
        
        System.out.println("\n\nList after Quick Sort....!");
        quick.showList();
    }
    
}
