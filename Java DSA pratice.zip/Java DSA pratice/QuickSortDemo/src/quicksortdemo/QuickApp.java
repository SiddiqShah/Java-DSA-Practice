package quicksortdemo;

import java.util.Random;

public class QuickApp 
{
    int[] List;
    
    public QuickApp(int N)
    {
        List = new int[N];
        
        Random r = new Random();
        for(int i=0; i < List.length; i++)
        {
            List[i] = (int)(Math.random()*20);
        }
        System.out.println("List Populated.......");
        
    }
    
    public void showList()
    {
        for(int i=0; i < List.length; i++)
        {
            System.out.print(List[i]+",");;
        }
        System.out.println("\n");
    }
    
    public void QuickSort(int left, int right)
    {
        if(left < right)
	{
            int p = Partition(left, right);
            QuickSort(left, p-1);
            QuickSort(p+1, right);
            
        }   
    }

    
    public int Partition(int left, int right)
    {
        int p = List[left];
        int l = left;
        int r = right;
        
        while(l < r)
        {
            while(l<r && List[l] <= p)
                l++;
            while(l<=r && List[r] > p)
                r--;
            
            if(l < r)
            {
                int temp = List[l];
                List[l] = List[r];
                List[r] = temp;
            }
        }
        List[left] = List[r];
        List[r] = p;
        
        return r;
        
    }
    
}
