package sortingapp;

import java.util.Arrays;
import java.util.Scanner;

public class SortingApp 
{

    public static void main(String[] args) 
    {
        Scanner kb = new Scanner(System.in);
        SortingAlgorithm S = new SortingAlgorithm(10);
        
        S.fillList(1, 100);
        S.showList();
        
        S.BubbleSort();
//        S.SelectionSort();

            //S.InsertionSort();
        
    }
}
