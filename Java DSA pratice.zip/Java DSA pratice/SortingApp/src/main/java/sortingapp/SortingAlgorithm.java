package sortingapp;

import java.util.Arrays;
import java.util.Random;

public class SortingAlgorithm 
{
    private int MasterList[];
    private int BubbleComparison;
    private int SelectionComparison;
     private int InsertionComparison;

    public SortingAlgorithm(int N)
    {
        MasterList = new int[N];
    }

    public void fillList(int min, int max)
    {
        Random r = new Random();
        for(int i=0; i<MasterList.length; i++)
        {
            MasterList[i] = r.nextInt(max-min+1)+min;
        }
        System.out.print("The list is populated.............\n\n");
    }

    public void BubbleSort()
    {
        int BubbleList[] = new int[MasterList.length];
        for(int i=0; i<BubbleList.length; i++)
        {
            BubbleList[i] = MasterList[i];
        }

        System.out.println("Original array (Bubble Sort): " + Arrays.toString(BubbleList));

        // Bubble sorting logic
        for(int outerloop=0; outerloop<BubbleList.length-1; outerloop++)
        {
            for(int innerloop=0; innerloop<BubbleList.length-outerloop-1; innerloop++)
            {
                // Compare adjacent elements and swap if necessary
                if (BubbleList[innerloop] > BubbleList[innerloop + 1]) 
                {
                    // Swap elements
                    int temp = BubbleList[innerloop];
                    BubbleList[innerloop] = BubbleList[innerloop + 1];
                    BubbleList[innerloop + 1] = temp;

                    // Print the array after each swap
                    System.out.println("Array after swapping: " + Arrays.toString(BubbleList));
                }
                
            }
            BubbleComparison++; // Increment comparison counter
        }
        System.out.println("Total Bubble Sort Comparisons: " + BubbleComparison+"\n");
    }

    public void SelectionSort()
    {
        int SelectionList[] = new int[MasterList.length]; 
        for(int i=0; i<SelectionList.length; i++)
        {
            SelectionList[i] = MasterList[i];
        }

        System.out.println("Original array (Selection Sort): " + Arrays.toString(SelectionList));

        // Selection sorting logic
        for(int i=0; i<SelectionList.length-1; i++)
        {
            int minimum = i;
            for(int j=i+1; j<SelectionList.length; j++) // Fix inner loop to start from i+1
            {
                if(SelectionList[minimum] > SelectionList[j])
                {
                    minimum = j; // Find the index of the minimum element
                }
               
            }
            // Swap the found minimum element with the first element
            int temp = SelectionList[minimum];
            SelectionList[minimum] = SelectionList[i];
            SelectionList[i] = temp;
            
             SelectionComparison++; // Increment comparison counter
            // Print the array after each swap
            System.out.println("Array after swapping: " + Arrays.toString(SelectionList));
        }
        
        System.out.println("Total Selection Sort Comparisons: " + SelectionComparison);
    }
    
   public void InsertionSort() {
    int[] InsertionList = new int[MasterList.length];
    for (int i = 0; i < InsertionList.length; i++) {
        InsertionList[i] = MasterList[i];
    }
    System.out.println("Original array (Insertion Sort): " + Arrays.toString(InsertionList));

    for (int i = 1; i < InsertionList.length; i++) {
        int current = InsertionList[i];
        int j = i - 1;
        while (j >= 0 && current < InsertionList[j]) {
            InsertionList[j + 1] = InsertionList[j];
            j--;
        }
        InsertionList[j + 1] = current;
        InsertionComparison++;
        System.out.println("Array after insertion: " + Arrays.toString(InsertionList));
    }

    System.out.println("Total Insertion Sort Comparisons: " + InsertionComparison);
    
//     for (int i = 1; i < array.length; i++) {
//           int value = array[i];
//           int j = i - 1;
//           
//           // Shift elements of array[0..i-1] that are greater than value
//           for (; j >= 0 && array[j] > value; j--) {
//               array[j + 1] = array[j];
//           }
//           array[j + 1] = value;
//       }
//       
//       for (int i = 0; i < array.length; i++) {
//           System.out.println("Array sorted: " + array[i]);
}


    public void showList()
    {
        System.out.println("The list items are: ");
        for (int i=0; i<MasterList.length; i++)
        {
            System.out.print(MasterList[i] + ", ");
        }
        System.out.println(); // For clean output
    }
}
