package thermostate1;


class thermostate
{
    private float currentTemp;
    private float desiredTemp;
    
    // Constructor
    thermostate(float currentTemp,
            float desiredTemp)
    {
        this.currentTemp = currentTemp;
        this.desiredTemp = desiredTemp;
    }
    
    // Getter for the current temp
    public float getCurrentTemp()
    {
        return currentTemp;
    }
    
    // setter for the current temp
    public void setCurrentTemp(float currentTemp)
    {
        this.currentTemp = currentTemp;
    }
    
    // Gettre for desired temp
    public float getDesiredTemp()
    {
        return desiredTemp;
    }
    
    // setter for desired temp
    public void setDesiredTemp(float desiredTemp)
    {
        this.desiredTemp = desiredTemp;
    }
    
    // Method to turn on furnace
    public void furnace_on()
    {
        System.out.println("Furnace is ON.");
    }
    
    // Method to turn off funace
    
    public void furnace_off()
    {
        System.out.println("Furnace is off.");
    }
    
}

public class Thermostate1 {
    public static void main(String[] args) {
        thermostate myThermostate = new thermostate(20.0f, 22.5f); // Corrected class name
        // Access the current and desired temperatures using getters
        float currentTemp = myThermostate.getCurrentTemp();
        float desiredTemp = myThermostate.getDesiredTemp();

        System.out.println("Current temperature: " + currentTemp);
        System.out.println("Desired temperature: " + desiredTemp);
        myThermostate.furnace_on();
        myThermostate.furnace_off();
    }
}
