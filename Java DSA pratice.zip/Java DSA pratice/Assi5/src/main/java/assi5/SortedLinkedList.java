/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assi5;

/**
 *
 * @author Siddiq Shah
 */

public class SortedLinkedList {
    
}
class SortedLinkedList {
    private Node head; // Head of the linked list

    public SortedLinkedList() {
        this.head = null;
    }

    // Insert a new node in sorted order
    public void insert(int key, String value) {
        Node newNode = new Node(key, value);
        if (head == null || head.key > key) {
            newNode.next = head;
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null && current.next.key <= key) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    // Remove the node with the smallest key
    public Node removeMin() {
        if (head == null) {
            return null; // List is empty
        }
        Node minNode = head;
        head = head.next;
        return minNode;
    }

    // Check if the list is empty
    public boolean isEmpty() {
        return head == null;
    }
}