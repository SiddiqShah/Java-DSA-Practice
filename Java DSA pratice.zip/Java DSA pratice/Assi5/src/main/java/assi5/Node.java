/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assi5;

/**
 *
 * @author Siddiq Shah
 */
public class Node {
    int priority;
    String data;
    Node next;

    public Node(int priority, String data) {
        this.priority = priority;
        this.data = data;
        this.next = null;
    }
}
