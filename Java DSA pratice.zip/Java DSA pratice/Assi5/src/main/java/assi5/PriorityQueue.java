/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assi5;

/**
 *
 * @author Siddiq Shah
 */
public class PriorityQueue {
    private Node head;

    public PriorityQueue() {
        this.head = null;
    }

    // Enqueue an element based on its priority
    public void enqueue(int priority, String data) {
        Node newNode = new Node(priority, data);

        // If the queue is empty or the new node has the highest priority
        if (head == null || head.priority > priority) {
            newNode.next = head;
            head = newNode;
        } else {
            // Traverse the list and insert in the correct position
            Node current = head;
            while (current.next != null && current.next.priority <= priority) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    // Dequeue the element with the highest priority
    public String dequeue() {
        if (head == null) {
            return null; // Queue is empty
        }
        String data = head.data;
        head = head.next;
        return data;
    }

    // Peek at the element with the highest priority
    public String peek() {
        return (head != null) ? head.data : null;
    }

    // Check if the queue is empty
    public boolean isEmpty() {
        return head == null;
    }

    // Print the priority queue
    public void printQueue() {
        Node current = head;
        while (current != null) {
            System.out.println("Data: " + current.data + " | Priority: " + current.priority);
            current = current.next;
        }
    }
}
class PriorityQueue {
    private SortedLinkedList sortedList;

    public PriorityQueue() {
        this.sortedList = new SortedLinkedList();
    }

    // Add an element to the priority queue
    public void enqueue(int key, String value) {
        sortedList.insert(key, value);
    }

    // Remove and return the element with the smallest key
    public String dequeue() {
        Node minNode = sortedList.removeMin();
        if (minNode != null) {
            return "Key: " + minNode.key + ", Value: " + minNode.value;
        }
        return null; // Queue is empty
    }

    // Check if the queue is empty
    public boolean isEmpty() {
        return sortedList.isEmpty();
    }
}