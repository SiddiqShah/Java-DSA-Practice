/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package assi5;

/**
 *
 * @author Siddiq Shah
 */
public class Assi5 {

    public class Main {
    public static void main(String[] args) {
        PriorityQueue pq = new PriorityQueue();

3120]        pq.enqueue(5, "Task 5");
        pq.enqueue(1, "Task 1");
        pq.enqueue(3, "Task 3");

        while (!pq.isEmpty()) {
            System.out.println(pq.dequeue());
        }
    }
    }
}
    
