
package recursiondemos;

public class RecursiveAlgos 
{    
   public int EuGCD(int M, int N)
   {
       if(M == N)
           return N;
       else if(M < N)
           return EuGCD(M, N-M);
       else
           return EuGCD(M-N, N);
           
   }
   
   public int Fibonacci(int N)
   {
        if (N == 1)
           return 0;
        else if (N == 2)
            return 1;
        return Fibonacci(N-1) + Fibonacci(N-2); 
    } 
   
   public int Triangular(int num)
    {
        if(num == 1)
            return 1;
        else
            return num + Triangular(num-1);
                    
        
    }
   
   int SquarSum(int N) 
   {
        if (N == 0) 
        {
            return 0;             // basis
        }
        return SquarSum(N-1) + N*N;  // recursion
    }
   
   public int RecSum(int[] A, int n)
   {
       if(n == 0)
           return A[n];
       else
           return A[n] + RecSum(A, n-1);
   }
   
        
}
