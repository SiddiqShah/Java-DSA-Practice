package mavenproject1;

public class Sales 
{
    float salesRec[];
    
    Sales()
    {
        salesRec = new float[12];
    }
    
    public void display()
    {
        for(int i=0; i< salesRec.length; i++)
        {
            System.out.println("Month-"+(i=1)+salesRec[i]);
        }
    }
    
}
