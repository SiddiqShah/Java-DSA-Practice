package mavenproject1;

public class SalesApp 
{

    public static void main(String[] args) 
    {
        Sales s1 = new Sales();
        s1.display();
    }
}
