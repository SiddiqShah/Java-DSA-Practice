package searchingapp;

import java.util.*;

public class Searching 
{
    private int List[];
    
    public Searching(int N)
    {
        List = new int[N];
    }
    
    public void fillList(int min, int max)
    {
        Random r = new Random();
        for(int i=0; i<List.length; i++)
        {
            List[i] = r.nextInt(max-min+1)+min;
        }
        System.out.println("The list is populated.............\n\n");
    }
    
    public void showList()
    {
        System.out.println("The list items are: ");
        for (int i=0; i<List.length; i++)
        {
            System.out.println(List[i]+",");
        }
    }
    
//    public int SingleLinearSearch(int key)
//{
//    // Check if the list is null to avoid NullPointerException
//    if (List == null) {
//        return -1; // or handle it as appropriate
//    }
//    
//    // Iterate through the list
//    for (int i = 0; i < List.length; i++)
//    {
//        if (List[i] == key) // If the element matches the key
//            return i;       // Return the index
//    }
//    
//    return -1; // Key not found
//}

    public int singleLinearSearch(int key)
    {
        for (int i=0; i<List.length; i++)
        {
            if(List[i] == key)
                return i;
        }
        return -1;
    }
    
   public int BiDirectionalLinearSearch(int key)
{
    // Initialize middle point
    int middleIndex = List.length / 2;
    
    // Start from the middle and expand left and right
    int left = middleIndex-1;
    int right = middleIndex+1;

    // Loop until both sides are exhausted
    while (left >= 0 || right < List.length) {
        // Search towards the left side
       if (List[left] == key) {
                return left; // Key found on the left side
            } 

        // Search towards the right side
       else if (List[right] == key) {
                return right; // Key found on the right side
            }
       else
       {
           return middleIndex;
       }
    }

    // If key is not found in the entire list, return -1
    return -1;
}

    
   public int BinarySearch(int key) {
    int low = 0;
    int high = List.length - 1;
    int mid;

    while (low <= high) {
        mid = low + (high - low) / 2; // Safe calculation to avoid overflow

        if (List[mid] == key)
            return mid;
        else if(List[mid] < key)
            low = mid + 1;
        else
            high = mid - 1;
    }
    return -1; // Key not found
}
    
    public void sortesArray()
    {
        System.out.println("Sorted Array List.");
        Arrays.sort(List);
        showList();
        
    }
}
