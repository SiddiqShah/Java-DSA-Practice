package searchingapp;

import java.util.Scanner;

public class SearchingApp 
{
    public static void main(String[] args) 
    {
        Scanner kb = new Scanner(System.in);
        Searching S = new Searching(10);
        
        S.fillList(1, 100);
        S.showList();
        
        
        
        System.out.println("Enter your key:");
        int key = kb.nextInt();
        
        int location = S.BinarySearch(key);
        if(location == -1)
        {
            System.out.println("Key not found.");
        }
        else
        {
            System.out.println("Key: "+key +" :found at: "+location+" :location");
        }
        
//        location = S.BiDirectionalLinearSearch(key);
//        if(location == -1)
//        {
//            System.out.println("Key not found.");
//        }
//        else
//        {
//            System.out.println("Key: "+key +" :found at: "+location+" :location");
//        }

//            S.sortesArray();
//            System.out.println("Enter your key:");
//            int key = kb.nextInt();
//            int location = S.BinarySearch(key);
//            if(location == -1)
//        {
//            System.out.println("Key not found.");
//        }
//        else
//        {
//            System.out.println("Key: "+key +" :found at: "+location+" :location");
//        }
            
    }
    
}
