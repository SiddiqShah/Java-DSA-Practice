package linkedlistdemo;

public class LinkedList 
{
    Node head, tail;
    public int size;
    
    public void addFirst(int data)
    {
        // to add data at first to linked list you have to create newnode of oject Node
        Node newNode = new Node(data);
        size++;
        if(head == null)
        {
            head = tail = newNode;
            return;
        }
        
        // after creating new node you have to initialize the newNode.next to head
        newNode.next = head;
        
        // now initialize the head to newNode to add to linkedlist at start
        head = newNode;
    }
    
    public void addLast(int data)
    {
        //create new node
        Node newNode = new Node(data);
        size++;
        // if head is null
        if(head == null)
        {
            head = tail = newNode;
            return;
        }
        
        // point tail.next to newNode to lint with addlist node
        tail.next = newNode;
        // then point the tail to newNode to store the adrees of newNode
        tail = newNode;
    }
    
    public void addAtMiddle(int idx, int data)
    {
        if(idx == 0)
        {
            addFirst(data);
            return;
        }
        
        Node newNode = new Node(data);
        size++;
                
        Node temp = head;
        
        int i=0;
        while(i<idx-1)
        {
            temp = temp.next;
            i++;
        }
        
        newNode.next = temp.next;
        temp.next = newNode;
    }
    
    public int removeFirst()
    {
        if(size == 0)
        {
            System.out.println("LL is empty");
        } else if(size == 1)
        {
            int value = head.data;
            head = tail = null;
            size = 0;
            return value;
        }
        
        int value = head.data;
        head = head.next;
        size--;
        return value;
    }
    
    public int removeLast()
    {
        if(size == 0)
        {
            System.out.println("LL is empty");
        } else if(size == 1) {
            int value = head.data;
            head = tail = null;
            size = 0;
            return value;
        }
        
        Node previous = head;
        for(int i=0; i<size-2; i++)
        {
            previous = previous.next;
        }
        
        int value = tail.data;
        previous.next = null;
        tail = previous;
        size--;
        return value;
    }
    
    public int searchKey(int key)
    {
        Node temp = head;
        int i = 0;
        
        while(temp != null)
        {
            if(temp.data == key)
            {
                System.out.println("Key found at index "+i);
                return i;
            }
            
            temp = temp.next;
            i++;
        }
        
        System.out.println("Key not found");
        return -1;
    }
    
    public void reverse() {
    Node prev = null;    // Previous node starts as null
    Node current = head; // Start from the head of the list
    Node next = null;    // To store the next node temporarily

    while (current != null) {
        next = current.next; // Save the next node
        current.next = prev; // Reverse the current node's link
        prev = current;      // Move 'prev' forward to the current node
        current = next;      // Move 'current' forward to the next node
    }

    head = prev; // Update the head to the new first node
}

    
    public void showList() 
    {
        if (head == null) 
        {
            System.out.println("List is empty.");
            return;
        }

        Node temp = head;
        System.out.print("Linked List: ");
        while (temp != null) 
        {
            System.out.print(temp.data + "->");
            temp = temp.next;
        }
        System.out.println("null");
    }
}
