package linkedlistdemo;

public class LinkedListDemo 
{
    public static void main(String[] args) 
    {
        LinkedList ll = new LinkedList();
        
        ll.addFirst(7);
        ll.addFirst(4);
        ll.showList();
        
        ll.addLast(5);
        ll.showList();
        
        ll.addFirst(9);
        ll.addFirst(1);
        ll.showList();
        
        ll.addAtMiddle(3, 0);
        ll.showList();
        
        ll.addAtMiddle(4, 2);
        ll.showList();
        
//        ll.removeFirst();
//        ll.showList();
//        
//        ll.removeLast();
//        ll.showList();
        
//        ll.searchKey(2);
//        ll.searchKey(2);

          ll.reverse();
          ll.showList();
        
        System.out.println("Size of linked list: "+ll.size);
    }
}
